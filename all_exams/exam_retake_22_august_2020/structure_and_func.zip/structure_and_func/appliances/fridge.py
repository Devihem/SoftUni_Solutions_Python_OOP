from all_exams.exam_retake_22_august_2020.structure_and_func.appliances.appliance import Appliance


class Fridge(Appliance):
    def __init__(self):
        super().__init__(cost=1.2)
